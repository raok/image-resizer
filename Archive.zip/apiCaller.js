var http = require("http");
var querystring = require("querystring");
var _ = require("underscore");

apiCaller = {};

apiCaller.token = null;

apiCaller._get = function (context) {
    // request to obtain our oauth token
    var options = {
        method: "GET",
        host: "nightly.hevnly.com",
        path: "/oauth/v2/token",
        headers : {
            'Content-Type': "application/json",
            'Accept': "application/json"
        },
        client_id: "1_3tk0nlxobfeoow0cw4w400k8o0g008ww00o44gookgskc8ggkw",
        client_secret: "38nay3fseqkg0cw80kk4scookoookoskc0c84c4ckkgk4884k8",
        grant_type: "client_credentials"
    };

    var callback = function(response) {
        var str = '';

        //another chunk of data has been recieved, so append it to `str`
        response.on('data', function (chunk) {
            str += chunk;
        });

        // error response
        response.on("error", function (error) {
            console.log("Something went wrong with the api, get request, : %s", error.message);
            context.done(new Error("Something went wrong with the api, get request"));
        });

        //the whole response has been recieved, so we just print it out here
        response.on('end', function () {
            console.log("get request ended with result --->  %s", str);
            apiCaller.token = JSON.parse(str).access_token;
            // we want to stop the request if token is not correct
            if(!JSON.parse(str).access_token) {
                console.log("Token: %s", apiCaller.token);
                context.done(new Error("Something went wrong with the token. Wrong token!"));
            }
        });
    };

    http.request(options, callback).end();
}

apiCaller._post = function (imgId, sizesConfigs, context) {

   // request to tell our api images were resized
    var post_options = {
        method: "POST",
        host:"nightly.hevnly.com",
        path: "/img/" + imgId + "/resized",
        headers: {
            'Content-Type': "application/x-www-form-urlencoded",
            'Accept': "application/x-www-form-urlencoded",
            'Header key': 'Authorization',
            'Header value': 'Bearer ' + apiCaller.token
        }
    };

    var data = querystring.stringify(_.map(sizesConfigs, function (num) {return num.destinationPath}));

    var post_callback = function(response) {

        response.on('data', function (chunk) {
            console.log("body: " + chunk);
        });
        // error response
        response.on("error", function (error) {
            context.done(new Error("Something went wrong with the api, put request"));
        });

        response.on('end', function () {
            console.log("Ended response for post request with result");
        });
    };

    var request = http.request(post_options, post_callback);

    request.end(data, function () {
        context.done(null, 'Post request successful');
    });
}

module.exports = apiCaller;